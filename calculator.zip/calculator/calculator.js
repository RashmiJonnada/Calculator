let currentExpression = '';
    function press(value) {
      currentExpression += value;
      document.getElementById('display').textContent = currentExpression;
    }

    function clearDisplay() {
      currentExpression = '';
      document.getElementById('display').textContent = '0';
    }

    function backspace() {
      currentExpression = currentExpression.slice(0, -1);
      document.getElementById('display').textContent = currentExpression || '0';
    }

    function calculate() {
      try {
        if (currentExpression.includes('/0')) {
          alert('Division by zero is not possible');
          return;
        }

        const result = eval(currentExpression);
        if (!isFinite(result)) {
          alert('Division by zero is not possible');
          return;
        }

        const record = `${currentExpression} = ${result}`;
        currentExpression = result.toString();
        document.getElementById('display').textContent = currentExpression;
        document.getElementById('current-output').textContent = `Result: ${result}`;
        saveToHistory(record);
        renderHistory();
      } catch (err) {
        document.getElementById('display').textContent = 'Error';
        document.getElementById('current-output').textContent = 'Result: Error';
        currentExpression = '';
      }
    }

    function saveToHistory(item) {
      let history = JSON.parse(localStorage.getItem('calcHistory')) || [];
      history.unshift(item);
      if (history.length > 10) history.pop();
      localStorage.setItem('calcHistory', JSON.stringify(history));
    }

    function renderHistory() {
      const historyList = document.getElementById('history-list');
      const history = JSON.parse(localStorage.getItem('calcHistory')) || [];
      historyList.innerHTML = history.map(item => `<div class="history-item">${item}</div>`).join('');
    }

    function clearHistory() {
      localStorage.removeItem('calcHistory');
      renderHistory();
      document.getElementById('current-output').textContent = 'Result: 0';
    }

    window.onload = function () {
      renderHistory();
      document.getElementById('current-output').textContent = 'Result: 0';
    };